Please Run Command:
java -jar Routing.jar